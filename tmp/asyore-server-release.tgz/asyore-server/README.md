# asyore-server

「由迹而寻」的 Node.js 20 + MongoDB 后端基础工程。目前提供存活、就绪和 API 版本入口，尚未启用微信登录与训练数据同步。

## 本地启动

```powershell
npm.cmd install
Copy-Item .env.example .env
# 修改 .env，只在本机保存真实密钥
npm.cmd test
npm.cmd start
```

健康检查：

- `GET /fitness-api/health/live`：进程存活，不依赖 MongoDB。
- `GET /fitness-api/health`：服务和 MongoDB 就绪状态。
- `GET /fitness-api/v1`：API 版本入口。

## 生产目录

推荐部署到 `/home/ubuntu/asyore-server`，使用 `ecosystem.config.cjs` 交由 PM2 管理。Nginx 模板位于 `deploy/nginx-asyore.conf.example`。

服务器 `.env` 必须至少包含 `MONGODB_URI`，并应通过服务器环境或密钥管理服务配置微信、JWT 与 COS 密钥。不得从前端或 Markdown 复制明文密钥进入代码仓库。

## 上线前待实现

- 微信 code 登录、服务端 `code2Session` 和项目访问令牌。
- 用户档案、训练会话、组记录、打卡与幂等同步模型。
- 数据导出、账号删除、接口限流和审计日志。
- MongoDB 索引、备份恢复演练与监控告警。
