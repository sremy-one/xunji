module.exports = {
  apps: [{
    name: 'asyore-server',
    script: 'src/server.js',
    cwd: '/home/ubuntu/asyore-server',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_memory_restart: '512M',
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
    },
  }],
}
