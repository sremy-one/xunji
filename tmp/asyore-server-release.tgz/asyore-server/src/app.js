import cors from 'cors'
import express from 'express'
import helmet from 'helmet'
import { databaseHealth } from './db/mongo.js'

function corsOptions(allowedOrigins) {
  return {
    credentials: false,
    origin(origin, callback) {
      if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
        callback(null, true)
        return
      }
      callback(new Error('Origin is not allowed'))
    },
  }
}

export function createApp({ config, getDatabaseHealth = databaseHealth }) {
  const app = express()
  app.disable('x-powered-by')
  app.set('trust proxy', config.trustProxy)
  app.use(helmet())
  app.use(cors(corsOptions(config.corsOrigins)))
  app.use(express.json({ limit: '100kb' }))

  app.get('/fitness-api/health/live', (_request, response) => {
    response.json({ status: 'ok', service: 'asyore-server' })
  })

  app.get('/fitness-api/health', (_request, response) => {
    const database = getDatabaseHealth()
    response.status(database.connected ? 200 : 503).json({
      status: database.connected ? 'ok' : 'degraded',
      service: 'asyore-server',
      database,
      timestamp: new Date().toISOString(),
    })
  })

  app.get('/fitness-api/v1', (_request, response) => {
    response.json({ service: 'asyore-server', version: 'v1' })
  })

  app.use((_request, response) => {
    response.status(404).json({ code: 'NOT_FOUND', message: 'Resource not found' })
  })

  app.use((error, _request, response, _next) => {
    console.error(JSON.stringify({ level: 'error', message: error.message }))
    response.status(500).json({ code: 'INTERNAL_ERROR', message: 'Internal server error' })
  })

  return app
}
