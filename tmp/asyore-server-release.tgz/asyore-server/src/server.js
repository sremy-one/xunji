import 'dotenv/config'
import { createServer } from 'node:http'
import { createApp } from './app.js'
import { loadConfig } from './config/env.js'
import { connectDatabase, disconnectDatabase } from './db/mongo.js'

const config = loadConfig()
await connectDatabase(config)

const app = createApp({ config })
const server = createServer(app)

server.listen(config.port, '127.0.0.1', () => {
  console.log(JSON.stringify({
    level: 'info',
    message: 'asyore-server started',
    port: config.port,
    environment: config.nodeEnv,
  }))
})

async function shutdown(signal) {
  console.log(JSON.stringify({ level: 'info', message: 'shutdown requested', signal }))
  server.close(async () => {
    await disconnectDatabase()
    process.exit(0)
  })
  setTimeout(() => process.exit(1), 10000).unref()
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
