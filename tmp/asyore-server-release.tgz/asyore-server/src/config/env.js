function required(source, key) {
  const value = source[key]?.trim()
  if (!value) throw new Error(`Missing required environment variable: ${key}`)
  return value
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value || '', 10)
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback
}

export function loadConfig(source = process.env) {
  const nodeEnv = source.NODE_ENV?.trim() || 'development'
  return Object.freeze({
    nodeEnv,
    port: positiveInteger(source.PORT, 3000),
    trustProxy: positiveInteger(source.TRUST_PROXY, 1),
    mongoUri: required(source, 'MONGODB_URI'),
    mongoDbName: source.MONGODB_DB_NAME?.trim() || 'asyore_db',
    corsOrigins: (source.CORS_ORIGINS || '')
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean),
  })
}
