import mongoose from 'mongoose'

export async function connectDatabase(config) {
  mongoose.set('strictQuery', true)
  await mongoose.connect(config.mongoUri, {
    dbName: config.mongoDbName,
    serverSelectionTimeoutMS: 10000,
    maxPoolSize: 10,
  })
}

export function databaseHealth() {
  const readyState = mongoose.connection.readyState
  return {
    connected: readyState === 1,
    readyState,
  }
}

export async function disconnectDatabase() {
  if (mongoose.connection.readyState !== 0) await mongoose.disconnect()
}
