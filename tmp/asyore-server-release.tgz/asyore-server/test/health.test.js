import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import test from 'node:test'
import { createApp } from '../src/app.js'

const config = { trustProxy: 1, corsOrigins: [] }

async function withServer(app, callback) {
  const server = createServer(app)
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  try {
    await callback(`http://127.0.0.1:${address.port}`)
  } finally {
    await new Promise((resolve) => server.close(resolve))
  }
}

test('liveness endpoint does not depend on MongoDB', async () => {
  await withServer(createApp({ config }), async (baseUrl) => {
    const response = await fetch(`${baseUrl}/fitness-api/health/live`)
    assert.equal(response.status, 200)
    assert.equal((await response.json()).status, 'ok')
  })
})

test('readiness endpoint reports the database state', async () => {
  const app = createApp({
    config,
    getDatabaseHealth: () => ({ connected: true, readyState: 1 }),
  })
  await withServer(app, async (baseUrl) => {
    const response = await fetch(`${baseUrl}/fitness-api/health`)
    const body = await response.json()
    assert.equal(response.status, 200)
    assert.equal(body.database.connected, true)
  })
})
