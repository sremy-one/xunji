import assert from 'node:assert/strict'
import test from 'node:test'
import { loadConfig } from '../src/config/env.js'

test('loadConfig requires a MongoDB URI', () => {
  assert.throws(() => loadConfig({}), /MONGODB_URI/)
})

test('loadConfig normalizes runtime values', () => {
  const config = loadConfig({
    NODE_ENV: 'test',
    PORT: '3100',
    TRUST_PROXY: '2',
    MONGODB_URI: 'mongodb://127.0.0.1:27017/test',
    CORS_ORIGINS: 'https://asyore.cn, https://admin.asyore.cn ',
  })
  assert.equal(config.port, 3100)
  assert.equal(config.trustProxy, 2)
  assert.deepEqual(config.corsOrigins, ['https://asyore.cn', 'https://admin.asyore.cn'])
})
